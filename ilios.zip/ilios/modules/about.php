<?php
if($mobile)
{
?>
<div><img src="images/about.jpg" class="img-responsive" /></div>
<?php
}
else
{
?>
<div class="paditm" style="background:url(images/about.jpg) no-repeat; background-position:0px -200px; background-size:cover; height:500px;"></div>
<?php
}
?>



<div class="paditm">
<div class="row">
<h1 class="h1 text-center" style="color:#000;">About Us</h1>
<div class="col-md-10 col-md-offset-1">
Built by engineers, Ilios Power is a company with a strong focus on quality and efficiency. Our highly qualified engineers have been at the forefront of the solar industry in India since its dawn. Ilios is not just any other EPC firm. At Ilios EPC stands for Ease, Price and Commitment. We execute with ease at the most comfortable price and deliver a commitment durable for a lifetime. Ilios has always been in the front to pass on the price dips to all our clients on a real time basis.we are always a year ahead of the industry, in price, technology and promise. Our prestigious clientele including solar prodigies like Sumeru Power, Cybercity Developers, My Home group are a testimony to this. 


</div>
</div>
</div>

<hr/>

<div class="paditm">
<h2 class="h3b text-center">Our Clients</h2>
<img src="images/clients.png" class="img-responsive" style="margin:40px auto;" />
</div>

<hr/>
<div class="paditm" id="why-ilios">
<div class="row">
<span class="h1yu"><img src="images/flash1.png" class="sunab" /> Why Ilios</span>
<div class="clearfix"></div>
<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/star.png" class="img-responsive bimage" />
<h3 class="h3bu">Trusted Brand in Solar</h3>
Ilios Power is one of India's fastest growing Solar Energy Companies in India founded by IIT alumni.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/scale.png" class="img-responsive bimage" />
<h3 class="h3bu">Reliability & Scale</h3>
With 55MW+ EPC, 95MW O&M, Ilios has setup residential rooftops to large scale MW plants.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/timer.png" class="img-responsive bimage" />
<h3 class="h3bu">Execution & Quality</h3>
Our friendly team will make sure you get the best experience from initial consultation to installation to maintenance.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/chip.png" class="img-responsive bimage" />
<h3 class="h3bu">Technology Innovation</h3>
Our proprietary machine learning and analytics tools helps us maintain an uptime of 99.9%.
</div>
</div>

</div>
</div>



<script>
$(document).ready(function(){
  $("a").on('click', function(event) {
    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
        window.location.hash = hash;
      });
    }
  });
});
</script>

<script type="text/javascript">
jQuery(function($) {
var $cache = $('#getFixed');
var vTop = $cache.offset().top - parseFloat($cache.css('marginTop').replace(/auto/, 0));
  $(window).scroll(function (event) {
    var y = $(this).scrollTop();

    if (y >= vTop) {
      $cache.addClass('stuck');
    } else {
      $cache.removeClass('stuck');
    }
  });
});
</script>    
    