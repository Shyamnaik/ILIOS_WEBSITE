<div class="submenu hidden-xs" id="getFixed">
<div class="submenuitem"><a href="#industries">Industries</a></div>
<div class="submenuitem"><a href="javascript:void(0);" data-toggle="modal" data-target="#solarcalc">Savings Calculator</a></div>
<div class="submenuitem"><a href="#why-ilios">Why Ilios</a></div>
<div class="submenuitem"><a href="#how-it-works">How it works</a></div>
<div class="submenuitem"><a href="#getstarted">Get Started</a></div>
</div>

<?php
if($mobile)
{
?>
<div><img src="images/light3.png" class="img-responsive" /></div>
<?php
}
else
{
?>
<div class="patim" style="background:url(images/light3.png) no-repeat; background-position:0px -200px; background-size:cover; height:600px;"></div>
<?php
}
?>






<div class="paditm" style=" padding-bottom:80px;" id="industries">
<div class="row text-center">
<h1 class="h1 text-center">Solar Solutions for Industrial Sector</h1>

<div class="col-md-6 col-md-offset-3">

<img src="images/switch.png" class="img-responsive" style="max-width:150px; margin:0px auto; padding:20px;" />
Ilios Power has the experience and expertise to help large scale power intensive industries switch to solar power. Industries which can benefit from solar power are
<hr/>

</div>

</div>

<div class="row">
<div class="col-md-3 col-md-offset-5">
<div class="indulist">
<img src="images/sun2.png" height="25" /> &nbsp; Textile Industry
<hr/>
<img src="images/sun2.png" height="25" /> &nbsp; Food Industry
<hr/>
<img src="images/sun2.png" height="25" /> &nbsp; Metals & Chemicals
<hr/>
<img src="images/sun2.png" height="25" /> &nbsp; Cement Industry
<hr/>
<img src="images/sun2.png" height="25" /> &nbsp; Machinery & Equipment
<hr/>


</div>
</div>

</div>



</div>


<div class="paditm" style="background:url(images/indus.jpeg) no-repeat; background-size:cover; min-height:600px;">
<div class="row">
<div class="col-md-10" style="color:#FFF; padding-top:40px;">
<h3 class="h1" style="color:#FFF;">Solar Power for Industries</h3>
Industrial Sector consumes more than 30% of electricity in India. Most of the industries use alternative energy sources such as Diesel Generator for backup which further increase cost of energy. With increasing energy demand, the contracted load of industries is increasing resulting in higher fixed demand charges. Power intensive indutries in India need low cost and reliable alternate sources of electricity and solar rooftop can meet their requirement.

<div class="clearfix"></div>
<a href="" class="btn btn-border">Calculate Savings &raquo;</a>


</div>
</div>
</div>


<div class="paditx">
<div class="row row-eq-height" style="color: #036;">
<div class="col-md-7" style="padding:0px;"><img src="images/indus1.jpeg" class="img-responsive" /></div>
<div class="col-md-5" style="padding:50px; background:#B9C9E3;">
<h3 class="h1" style="color:#000;">Customized Rooftop Solution with Maximum Savings</h3>
Our Solar Energy solutions can take unit cost of electricity to as low as INR 4. For a customer who consumes around 50000 units, this can result in savings of more than INR 2 lakhs. When compared with cost of diesel generator back up, the amount of savings will be much higher. Your industry can consume solar power for around 25 years.
</div>
</div>
</div>




<div class="paditm">
<div class="row">
<div class="col-md-6" style="padding:30px;">
<h2 class="h1 text-center">Life-Time Maintenance Support</h2>
<img src="images/tools.png" class="img-responsive bimage" style="margin:0px auto;" />
Ilios solar rooftops are designed according to your roof condition and electricity consumption. This helps in lower maintenance costs and higher performance of plant
Ilios provides monitoring of plant performance with alert system for customers. Scheduled plant visits for cleaning and maintenance will be carried out during the plant life time.
</div>


<div class="col-md-6" style="padding:30px;">
<h2 class="h1 text-center">Support in Saving your Profits</h2>
<img src="images/save.png" class="img-responsive bimage" style="margin:0px auto;" />
Ilios Solar Energy Plant can be depreciated using Accelerated Depreciation Method. Accelerated Depreciation can lessen your tax burden increasing realization of your profits. Starting from 2017 April, industries can take advantage of 40% of project cost in first year and 40% of project cost in second year. For example, if you set up a 100kW plant with capital cost of 55 lakhs, you can write off payable tax upto 6 lakhs.</div>

</div>
</div>


<div class="paditm" style="border-bottom:1px solid #DDD; background:url(/images/pw_pattern.png);">
<div class="row">
<div class="col-xs-10 col-xs-offset-1 text-center">
<h3 class="h1" style="color:#000;">Technology & Performance Monitoring</h3>
<img src="images/tech.png" class="img-responsive" style="margin:30px auto 60px auto;" />
Ilios has developed proprietory software for data acquisition and monitoring plant performance. With analytics incorporated in plant operations and maintenance, Ilios Power has managed plant uptime of 99.9%. Online dashboards with alert systems are provided to customers for transparent monitoring.
</div>
</div>
</div>

<div class="paditm" id="why-ilios">
<div class="row">
<span class="h1yu"><img src="images/flash1.png" class="sunab" /> Why Ilios</span>
<div class="clearfix"></div>
<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/star.png" class="img-responsive bimage" />
<h3 class="h3bu">Trusted Brand in Solar</h3>
Ilios Power is one of India's fastest growing Solar Energy Companies in India founded by IIT alumni.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/scale.png" class="img-responsive bimage" />
<h3 class="h3bu">Reliability & Scale</h3>
With 55MW+ EPC, 95MW O&M, Ilios has setup residential rooftops to large scale MW plants.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/timer.png" class="img-responsive bimage" />
<h3 class="h3bu">Execution & Quality</h3>
Our friendly team will make sure you get the best experience from initial consultation to installation to maintenance.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/chip.png" class="img-responsive bimage" />
<h3 class="h3bu">Technology Innovation</h3>
Our proprietary machine learning and analytics tools helps us maintain an uptime of 99.9%.
</div>
</div>

</div>
</div>



<div class="paditm" id="how-it-works">
<div class="row">
<div class="col-xs-12">
<hr/>
<h2 class="h1 text-center">How it works</h2>
<hr/>
<img src="images/steps-comm.png" class="img-responsive" style="margin:0px auto;" />
</div>
</div>
</div>



<script type="text/javascript">
jQuery(function($) {
var $cache = $('#getFixed');
var vTop = $cache.offset().top - parseFloat($cache.css('marginTop').replace(/auto/, 0));
  $(window).scroll(function (event) {
    var y = $(this).scrollTop();

    if (y >= vTop) {
      $cache.addClass('stuck');
    } else {
      $cache.removeClass('stuck');
    }
  });
});
</script>    
    