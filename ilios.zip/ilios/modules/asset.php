<?php
if($mobile)
{
?>
<div><img src="images/panels.jpg" class="img-responsive" /></div>
<?php
}
else
{
?>
<div class="paditm" style="background:url(images/panels.jpg) no-repeat;  background-size:cover; height:500px;">
</div>

<?php
}
?>



<div class="paditm">
<div class="row">
<h1 class="h1 text-center" style="color:#000;">Solar Power Plant Operations and Maintenance</h1>
<div class="col-md-8" style="padding:50px;">
Ilios Power meticulous Operations and Maintenance strives for 100% plant uptime and maximum power generation<hr/>


<img src="images/sun2.png" height="25" /> &nbsp; Managing solar plants with capacity more than 30MW 
<hr/>
<img src="images/sun2.png" height="25" /> &nbsp; Proprietary analytics and monitoring software helps in proactive maintenance of plant
<hr/>
<img src="images/sun2.png" height="25" /> &nbsp; We leverage power of data science to optimize plant performance
<hr/>
<img src="images/sun2.png" height="25" /> &nbsp; With strong on field, technical and analytics teams, our O & M strategy ensures expected power generation through life time

</div>
<div class="col-md-4 hidden-xs"><div style="height:100%; display:inline-block; vertical-align:middle;"><img src="/images/tools1.png" class="img-responsive" style="vertical-align:middle; display:inline-block"  /></div></div>

</div>
</div>

<hr/>

<div class="paditm" id="why-ilios">
<div class="row">
<span class="h1yu"><img src="images/flash1.png" class="sunab" /> Why Ilios</span>
<div class="clearfix"></div>
<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/star.png" class="img-responsive bimage" />
<h3 class="h3bu">Trusted Brand in Solar</h3>
Ilios Power is one of India's fastest growing Solar Energy Companies in India founded by IIT alumni.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/scale.png" class="img-responsive bimage" />
<h3 class="h3bu">Reliability & Scale</h3>
With 55MW+ EPC, 95MW O&M, Ilios has setup residential rooftops to large scale MW plants.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/timer.png" class="img-responsive bimage" />
<h3 class="h3bu">Execution & Quality</h3>
Our friendly team will make sure you get the best experience from initial consultation to installation to maintenance.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/chip.png" class="img-responsive bimage" />
<h3 class="h3bu">Technology Innovation</h3>
Our proprietary machine learning and analytics tools helps us maintain an uptime of 99.9%.
</div>
</div>

</div>
</div>



<script>
$(document).ready(function(){
  $("a").on('click', function(event) {
    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
        window.location.hash = hash;
      });
    }
  });
});
</script>

<script type="text/javascript">
jQuery(function($) {
var $cache = $('#getFixed');
var vTop = $cache.offset().top - parseFloat($cache.css('marginTop').replace(/auto/, 0));
  $(window).scroll(function (event) {
    var y = $(this).scrollTop();

    if (y >= vTop) {
      $cache.addClass('stuck');
    } else {
      $cache.removeClass('stuck');
    }
  });
});
</script>    
    