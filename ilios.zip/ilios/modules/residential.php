<div class="submenu hidden-xs" id="getFixed">
<div class="submenuitem"><a href="#rooftops">Rooftops</a></div>
<div class="submenuitem"><a href="#" data-toggle="modal" data-target="#solarcalc">Savings Calculator</a></div>
<div class="submenuitem"><a href="#why-ilios">Why Ilios</a></div>
<div class="submenuitem"><a href="#how-it-works">How it works</a></div>
<div class="submenuitem"><a href="#getstarted">Get Started</a></div>
</div>
<?php
if($mobile)
{
?>
<div style="margin-bottom:30px;"><img src="big/7.jpeg" class="img-responsive" /></div>
<?php
}
else
{
?>
<div class="patim" style="background:url(big/7.jpeg) no-repeat; background-position:0px -200px; background-size:cover; height:600px;"></div>
<?php
}
?>

<div class="paditm" style="padding-top:0px; padding-bottom:80px;">
<div class="row text-center">
<h1 class="h1 text-center">We make it simple to switch to solar!</h1>

<div class="col-md-6 col-md-offset-3">

<img src="images/switch.png" class="img-responsive" style="max-width:150px; margin:0px auto; padding:20px;" />

We offer affordable and world-class solar solutions to power your home. Be it Independent Houses, Gated Communities or High Rise Buildings we make it easy right from installtion to maintenance. Residential customers can not only avail subsidy on solar rooftops but also save big in the long run via Net Metering Scheme. With simple regulations and easy finance options, solar plant for your home can installed even in a day! 
</div>
</div>
</div>







<div class="paditm" style="background:url(images/home1.jpeg) no-repeat; background-size:cover; min-height:750px;" id="rooftops">
<div class="row">
<div class="col-xs-9" style="color:#000;">
<h3 class="h1">Customized to meet Your electricity needs</h3>
We tailor the plant size and design to suit loads of your appliances and patterns of usage
Ilios Solar Rooftop can serve as inverter for uninterruped power supply during power cuts
Ilios Power can integrate solar rooftop with existing battery + inverter system
You can run high loads such as Air Conditioners and refrigerators on solar power
</div>
</div>
</div>


<div class="paditm">
<div class="row">
<div class="col-md-8" style="padding:50px;">
<h3 class="h1" style="color:#ffd71e; margin-bottom:20px;">Designed to minimize your power expenses</h3>

<img src="images/sun2.png" height="25" /> &nbsp; Ilios unique price advantage can bring down unit cost of electricity to Rs.4
<hr/>
<img src="images/sun2.png" height="25" /> &nbsp;Reduce monthly electricity bills is from 25-75%
<hr/>
<img src="images/sun2.png" height="25" /> &nbsp;With a subsidy of 30%, earn monetary profits for more than 20 years
<hr/>
<img src="images/sun2.png" height="25" /> &nbsp; Minimum assured performance of plant over major period of life time

</div>
<div class="col-md-4 hidden-xs"><div style="height:100%; display:inline-block; vertical-align:middle;"><img src="/images/battery1.png" class="img-responsive" style="vertical-align:middle; display:inline-block"  /></div></div>

</div>
</div>


<div class="paditx">
<div class="row row-eq-height" style="color:#E8DDC9;">
<div class="col-md-8" style="padding:0px;"><img src="images/home2.jpeg" class="img-responsive" /></div>
<div class="col-md-4" style="padding:50px; background:#4B3831; min-height:100%;">
<h3 class="h1" style="color:#FFF; margin-bottom:20px;">Life-Time Support & Maintenance</h3>
Ilios has developed proprietory software for data acquisition and monitoring plant performance. Online dashboards with alert systems are implemented for proactive maintenance. Scheduled visits to plants are carried out to ensure quality of service and output.
</div>

</div>
</div>

<div class="paditm" id="why-ilios">
<div class="row">
<span class="h1yu"><img src="images/flash1.png" class="sunab" /> Why Ilios</span>
<div class="clearfix"></div>
<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/star.png" class="img-responsive bimage" />
<h3 class="h3bu">Trusted Brand in Solar</h3>
Ilios Power is one of India's fastest growing Solar Energy Companies in India founded by IIT alumni.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/scale.png" class="img-responsive bimage" />
<h3 class="h3bu">Reliability & Scale</h3>
With 55MW+ EPC, 95MW O&M, Ilios has setup residential rooftops to large scale MW plants.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/timer.png" class="img-responsive bimage" />
<h3 class="h3bu">Execution & Quality</h3>
Our friendly team will make sure you get the best experience from initial consultation to installation to maintenance.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/chip.png" class="img-responsive bimage" />
<h3 class="h3bu">Technology Innovation</h3>
Our proprietary machine learning and analytics tools helps us maintain an uptime of 99.9%.
</div>
</div>

</div>
</div>

<div class="paditx">
<div class="row">
<div class="col-md-4 nopad" style="background:url(images/house1.jpeg) no-repeat; background-size:cover; height:400px; border-right:1px solid #FFF;">
<div class="padits overlayblack">
<h2 class="h2">Independent Houses</h2>
<div>Our solar panels not only generate energy on your roof, they can also generate cash in your pocket.</div>
</div>
</div>

<div class="col-md-4 nopad" style="background:url(images/house2.jpeg) no-repeat; background-size:cover; height:400px;  border-right:1px solid #FFF;">
<div class="padits overlayblack">
<h2 class="h2">Gated Communities</h2>
<div>Invest in Solar. Build Power Plants.</div>
</div>
</div>


<div class="col-md-4 nopad" style="background:url(images/house3.jpeg) no-repeat; background-size:cover; height:400px;">
<div class="padits overlayblack">
<h2 class="h2">High-Rise Buildings</h2>
<div>Invest in Solar. Build Power Plants.</div>
</div>
</div>
</div>
</div>

<div class="paditm" id="how-it-works">
<div class="row">
<div class="col-xs-12">
<h2 class="h1 text-center">How it works</h2>
<hr/>
<img src="/images/steps-residential.png" class="img-responsive" style="margin:0px auto;" />
</div>
</div>
</div>



<script type="text/javascript">
jQuery(function($) {
var $cache = $('#getFixed');
var vTop = $cache.offset().top - parseFloat($cache.css('marginTop').replace(/auto/, 0));
  $(window).scroll(function (event) {
    var y = $(this).scrollTop();

    if (y >= vTop) {
      $cache.addClass('stuck');
    } else {
      $cache.removeClass('stuck');
    }
  });
});
</script>    
        
    