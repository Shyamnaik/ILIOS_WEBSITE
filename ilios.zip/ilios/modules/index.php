


<div class="homepage-hero-module">
    <div class="video-container">
<div class="text-center headbox">
<span class="homehead"><img src="images/flash.png" height="40" /> Switch to Solar</span>
</div>

        <div class="filter"></div>
        <video autoplay loop class="fillWidth">
            <source src="video/MP4/Into-The-Woods.mp4" type="video/mp4" />Your browser does not support the video tag. I suggest you upgrade your browser.
            <source src="video/WEBM/Into-The-Woods.webm" type="video/webm" />Your browser does not support the video tag. I suggest you upgrade your browser.
        </video>
        <div class="poster hidden">
            <img src="video/SnapShots/Into-The-Woods.jpg" alt="">
        </div>
    </div>
</div>


<div class="paditm">
<div class="row">
<div class="col-md-8 col-md-offset-2 exptxt text-center">
<h1 class="h1 text-center">Solar Made Simple</h1>
<div class="yline"></div>
<p align="justify">We are one of India's fastest growing Solar Energy Companies. We offer affordable and world-class solar solutions across residential, commercial and industrial projects. We are at the forefront of technology innovation in the solar sector with our proprietary machine learning and analytics tools. Our friendly team will make sure you get the best experience from initial consultation to installation to maintenance.</p></div>
</div>
</div>


<div class="paditx">
<div class="row">
<div class="col-md-4 nopad" style="background:url(big/7.jpeg) no-repeat; background-size:cover; height:400px;">
<div class="padits overlayblack">
<h2 class="h2">Residential</h2>
<div>We offer affordable and world-class solar solutions to power your home.</div>
<a href="residential.php" class="btn btn-border">View More &raquo;</a>
</div>
</div>

<div class="col-md-4 nopad" style="background:url(big/6.jpeg) no-repeat; background-size:cover; height:400px;">
<div class="padits overlayblack">
<h2 class="h2">Commercial</h2>
<div>Commercial segment has maximum potential for savings by adapting to solar power. </div>
<a href="commercial.php" class="btn btn-border">View More &raquo;</a>
</div>
</div>


<div class="col-md-4 nopad" style="background:url(big/10.jpeg) no-repeat; background-size:cover; height:400px;">
<div class="padits overlayblack">
<h2 class="h2">Industrial</h2>
<div>Power intensive indutries need low cost and reliable alternate sources of energy.</div>
<a href="industrial.php" class="btn btn-border">View More &raquo;</a>
</div>
</div>
</div>
</div>


<div class="paditm" id="why-ilios">
<div class="row">
<span class="h1yu"><img src="images/flash1.png" class="sunab" /> Why Ilios</span>
<div class="clearfix"></div>
<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/star.png" class="img-responsive bimage" />
<h3 class="h3bu">Trusted Brand in Solar</h3>
Ilios Power is one of India's fastest growing Solar Energy Companies in India founded by IIT alumni.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/scale.png" class="img-responsive bimage" />
<h3 class="h3bu">Reliability & Scale</h3>
With 55MW+ EPC, 95MW O&M, Ilios has setup residential rooftops to large scale MW plants.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/timer.png" class="img-responsive bimage" />
<h3 class="h3bu">Execution & Quality</h3>
Our friendly team will make sure you get the best experience from initial consultation to installation to maintenance.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/chip.png" class="img-responsive bimage" />
<h3 class="h3bu">Technology Innovation</h3>
Our proprietary machine learning and analytics tools helps us maintain an uptime of 99.9%.
</div>
</div>

</div>
</div>


<div class="paditm">
<h2 class="h1 text-center">Our Clients</h2>
<div class="row">
<div class="col-md-6 col-md-offset-3">
<hr/>
<img src="images/clients.png" class="img-responsive" style="margin:40px auto; max-height:200px; " />
</div>
</div>

</div>



<script type="text/javascript">
//jQuery is required to run this code
$( document ).ready(function() {

    //scaleVideoContainer();

    initBannerVideoSize('.video-container .poster img');
    initBannerVideoSize('.video-container .filter');
    initBannerVideoSize('.video-container video');

    $(window).on('resize', function() {
        scaleVideoContainer();
        scaleBannerVideoSize('.video-container .poster img');
        scaleBannerVideoSize('.video-container .filter');
        scaleBannerVideoSize('.video-container video');
    });

});

function scaleVideoContainer() {

    var height = $(window).height() + 5;
    var unitHeight = parseInt(height) + 'px';
    $('.homepage-hero-module').css('height',unitHeight);

}

function initBannerVideoSize(element){

    $(element).each(function(){
        $(this).data('height', $(this).height());
        $(this).data('width', $(this).width());
    });

    scaleBannerVideoSize(element);

}

function scaleBannerVideoSize(element){

    var windowWidth = $(window).width(),
    windowHeight = $(window).height() + 5,
    videoWidth,
    videoHeight;

    // console.log(windowHeight);

    $(element).each(function(){
        var videoAspectRatio = $(this).data('height')/$(this).data('width');

        $(this).width(windowWidth);

        if(windowWidth < 1000){
            videoHeight = windowHeight;
            videoWidth = videoHeight / videoAspectRatio;
            $(this).css({'margin-top' : 0, 'margin-left' : -(videoWidth - windowWidth) / 2 + 'px'});

            $(this).width(videoWidth).height(videoHeight);
        }

        $('.homepage-hero-module .video-container video').addClass('fadeIn animated');

    });
}
</script>    