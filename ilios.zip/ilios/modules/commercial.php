<div class="submenu hidden-xs" id="getFixed">
<div class="submenuitem"><a href="#industries">Industries</a></div>
<div class="submenuitem"><a href="javascript:void(0);" data-toggle="modal" data-target="#solarcalc">Savings Calculator</a></div>
<div class="submenuitem"><a href="#why-ilios">Why Ilios</a></div>
<div class="submenuitem"><a href="#how-it-works">How it works</a></div>
<div class="submenuitem"><a href="#getstarted">Get Started</a></div>
</div>

<?php
if($mobile)
{
?>
<div><img src="images/comm7.jpeg" class="img-responsive" /></div>
<?php
}
else
{
?>
<div class="patim" style="background:url(images/comm7.jpeg) no-repeat; background-position:0px -200px; background-size:cover; height:600px;"></div>
<?php
}
?>




<div class="paditm" style=" padding-bottom:80px;" id="industries">
<div class="row text-center">
<h1 class="h1 text-center">Solar Solutions for Businesses</h1>

<div class="col-md-6 col-md-offset-3">

<img src="/images/switch.png" class="img-responsive" style="max-width:150px; margin:0px auto; padding:20px;" />
Ilios Power has the experience and expertise to help your business switch to solar power. Commerical customers who can benefit from solar power are
<hr/>

</div>

</div>

<div class="row">
<div class="col-md-3 col-md-offset-5">
<div class="indulist">
<img src="images/sun2.png" height="25" /> &nbsp; Hospitals
<hr/>
<img src="images/sun2.png" height="25" /> &nbsp; Educational Institutions
<hr/>
<img src="images/sun2.png" height="25" /> &nbsp; Hotels & Restaurants
<hr/>
<img src="images/sun2.png" height="25" /> &nbsp; Shopping Malls
<hr/>
<img src="images/sun2.png" height="25" /> &nbsp; Corporate Offices
<hr/>


</div>
</div>

</div>



</div>


<div class="paditm" style="background:url(images/comm1.jpg) no-repeat; background-size:cover; min-height:600px;">
<div class="row">
<div class="col-md-6" style="color:#FFF; padding-top:40px;">
<h3 class="h1" style="color:#FFF;">Solar Power for Commercial Buildings</h3>
Commercial Customers pay highest price per unit of electricity from the grid. Commercial segment has maximum potential for savings by adapting to solar power. Commerical Buildings can make use of idle rooftops for captive consumption of electricity. Tenants with long term lease agreements can invest in solar rooftop as an alternative to diesel generator backup. Owners with high common utility bills can invest in solar power to bring down the power bills.
<div class="clearfix"></div>
<a href="" class="btn btn-border">Calculate Savings &raquo;</a>


</div>
</div>
</div>


<div class="paditx">
<div class="row row-eq-height" style="color:#EEE;">
<div class="col-md-7" style="padding:0px;"><img src="images/comm3.jpeg" class="img-responsive" /></div>
<div class="col-md-5" style="padding:50px; background:#333;">
<h3 class="h1" style="color:#ffd71e;">Designed for Long Term Stability and Consumption</h3>
Ilios Power treats each commercial customer as different according to their lease and ownership agreements. Ilios solar plants can be installed on a shared basis with selected occupants in building consuming power. We design custom solar rooftop plants to suit needs of groups of consumers in a commercial establishment. For capacities higher than 1 MW, Ilios Power set up solar ground mounted plants under open access.

</div>
</div>
</div>




<div class="paditm">
<div class="row">
<div class="col-md-6" style="padding:30px;">
<h2 class="h1 text-center">Customized to Maximize Savings</h2>
<img src="images/save.png" class="img-responsive bimage" style="margin:0px auto;" />
With Ilios Solar Energy plants, your unit cost of electricity can reach as low as INR 4
Ilios Power can integrate your existing inverter + battery backup with solar energy plant
You can gain from savings accrued by using less diesel during power outages
With grid electricity escalating at 4% and fixed solar tarriffs, we design plants with capacity to maximize your savings
</div>


<div class="col-md-6" style="padding:30px;">
<h2 class="h1 text-center">Avail Tax Benefits</h2>
<img src="images/tax.png" class="img-responsive bimage" style="margin:0px auto;" />
Commercial customers can claim tax incentives based on accelerated depreciation
From April 2017, Solar power plant asset can be depreciated at rate of 40% in first year and 40 % in second year
By installing a 100kw plant at INR 55 lakhs, a commercial customer can write off tax upto INR 6 lakhs
</div>

</div>
</div>


<div class="paditm" style="border-bottom:1px solid #DDD; background:url(images/pw_pattern.png);">
<div class="row">
<div class="col-xs-10 col-xs-offset-1 text-center">
<h3 class="h1" style="color:#000;">Technology & Performance Monitoring</h3>
<img src="/images/tech.png" class="img-responsive" style="margin:30px auto 60px auto;" />
Ilios has developed proprietory software for data acquisition and monitoring plant performance. With analytics incorporated in plant operations and maintenance, Ilios Power has managed plant uptime of 99.9%. Online dashboards with alert systems are provided to customers for transparent monitoring.
</div>
</div>
</div>

<div class="paditm" id="why-ilios">
<div class="row">
<span class="h1yu"><img src="images/flash1.png" class="sunab" /> Why Ilios</span>
<div class="clearfix"></div>
<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/star.png" class="img-responsive bimage" />
<h3 class="h3bu">Trusted Brand in Solar</h3>
Ilios Power is one of India's fastest growing Solar Energy Companies in India founded by IIT alumni.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/scale.png" class="img-responsive bimage" />
<h3 class="h3bu">Reliability & Scale</h3>
With 55MW+ EPC, 95MW O&M, Ilios has setup residential rooftops to large scale MW plants.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/timer.png" class="img-responsive bimage" />
<h3 class="h3bu">Execution & Quality</h3>
Our friendly team will make sure you get the best experience from initial consultation to installation to maintenance.
</div>
</div>

<div class="col-sm-3 colblock">
<div class="blockstyle" align="center">
<img src="images/chip.png" class="img-responsive bimage" />
<h3 class="h3bu">Technology Innovation</h3>
Our proprietary machine learning and analytics tools helps us maintain an uptime of 99.9%.
</div>
</div>

</div>
</div>


<div class="paditm" id="how-it-works">
<div class="row">
<div class="col-xs-12">
<hr/>
<h2 class="h1 text-center">How it works</h2>
<hr/>
<img src="images/steps-comm.png" class="img-responsive" style="margin:0px auto;" />
</div>
</div>
</div>



<script type="text/javascript">
jQuery(function($) {
var $cache = $('#getFixed');
var vTop = $cache.offset().top - parseFloat($cache.css('marginTop').replace(/auto/, 0));
  $(window).scroll(function (event) {
    var y = $(this).scrollTop();

    if (y >= vTop) {
      $cache.addClass('stuck');
    } else {
      $cache.removeClass('stuck');
    }
  });
});
</script>    
    