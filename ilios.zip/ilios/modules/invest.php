<div class="paditm" style="background:url(big/9.jpg) no-repeat;background-size:cover; height:600px;">
</div>



<div class="row">
<div class="col-xs-6 col-xs-offset-3">
<h1 class="h1 text-center">Go Solar for your Residence</h1>

</div>
</div>

    