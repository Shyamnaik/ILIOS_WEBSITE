<div class="paditm">
<div class="row">
<h1 class="h1 text-center" style="color:#000;">Our Work</h1>
</div>
</div>

<div class="paditm">
<div class="row">

<div class="col-sm-6" style="padding:30px;">
<div class="list-group">
  <li class="list-group-item"><h3 class="h3bu"><img src="images/sun2.png" height="30" /> &nbsp; Telangana 12.5MW</h3></li>
  <li class="list-group-item" style="padding:0px;"><img src="images/work/3.jpg" class="img-responsive" /></li>
  <li class="list-group-item"><strong>Project Size:</strong> 12.5MW</li>
  <li class="list-group-item"><strong>Location:</strong> Telangana, AP</li>
  <li class="list-group-item"><strong>Commissioned Date:</strong> January 2017</li>
  <li class="list-group-item"><strong>Project USP:</strong> 12.5 MW commissioned in less than 3 Months</li>
</div>




</div>

<div class="col-sm-6" style="padding:30px;">
<div class="list-group">
  <li class="list-group-item"><h3 class="h3bu"><img src="images/sun2.png" height="30" /> &nbsp; Kurnool 5MW</h3></li>
  <li class="list-group-item" style="padding:0px;"><img src="images/work/1.jpg" class="img-responsive" /></li>
  <li class="list-group-item"><strong>Project Size:</strong> 5MW</li>
  <li class="list-group-item"><strong>Location:</strong> Kurnool, AP</li>
  <li class="list-group-item"><strong>Commissioned Date:</strong> September 2015</li>
  <li class="list-group-item"><strong>Project USP:</strong> Generated highest units/MW from January-June 2016 in AP</li>
</div>




</div>

<div class="col-sm-6" style="padding:30px;">
<div class="list-group">
  <li class="list-group-item"><h3 class="h3bu"><img src="images/sun2.png" height="30" /> &nbsp; Kurnool 6MW</h3></li>
  <li class="list-group-item" style="padding:0px;"><img src="images/work/2.jpg" class="img-responsive" /></li>
  <li class="list-group-item"><strong>Project Size:</strong> 6MW</li>
  <li class="list-group-item"><strong>Location:</strong> Kurnool, AP</li>
  <li class="list-group-item"><strong>Commissioned Date:</strong> April 2016</li>
  <li class="list-group-item"><strong>Project USP:</strong> Fixed Tilt Structure with generation exceeding expectations</li>
</div>




</div>

<div class="col-sm-6" style="padding:30px;">
<div class="list-group">
  <li class="list-group-item"><h3 class="h3bu"><img src="images/sun2.png" height="30" /> &nbsp; Nalgonda 1.1MW</h3></li>
  <li class="list-group-item" style="padding:0px;"><img src="images/work/2.jpg" class="img-responsive" /></li>
  <li class="list-group-item"><strong>Project Size:</strong> 1.1MW</li>
  <li class="list-group-item"><strong>Location:</strong> Nalgonda, Telangana</li>
  <li class="list-group-item"><strong>Commissioned Date:</strong> -</li>
  <li class="list-group-item"><strong>Project USP:</strong> Solar Plant with Tracking Facility</li>
</div>




</div>

<div class="col-sm-6" style="padding:30px;">
<div class="list-group">
  <li class="list-group-item"><h3 class="h3bu"><img src="images/sun2.png" height="30" /> &nbsp; Pune 780kWp</h3></li>
  <li class="list-group-item" style="padding:0px;"><img src="images/work/2.jpg" class="img-responsive" /></li>
  <li class="list-group-item"><strong>Project Size:</strong> 780kWp</li>
  <li class="list-group-item"><strong>Location:</strong> Pune, Maharashtra</li>
  <li class="list-group-item"><strong>Commissioned Date:</strong> August 2016</li>
  <li class="list-group-item"><strong>Project USP:</strong> Solar Plant for Captive Consuption for a Food processing industry</li>
</div>




</div>

</div>
</div>







<script>
$(document).ready(function(){
  $("a").on('click', function(event) {
    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
        window.location.hash = hash;
      });
    }
  });
});
</script>

<script type="text/javascript">
jQuery(function($) {
var $cache = $('#getFixed');
var vTop = $cache.offset().top - parseFloat($cache.css('marginTop').replace(/auto/, 0));
  $(window).scroll(function (event) {
    var y = $(this).scrollTop();

    if (y >= vTop) {
      $cache.addClass('stuck');
    } else {
      $cache.removeClass('stuck');
    }
  });
});
</script>    
    