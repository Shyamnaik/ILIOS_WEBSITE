function solarCalc(billamount, category, state, use) {	
	var data = {
		"cusType": "",
		"units": 0,
		"savings": 0,
		"slabrate": 0,
		"solarrate": 5,
		"plantcapacity": 0,
		"area": 0,
		"totalunits": 0,
		"lifetimesavings": 0,
		"percentuse": 100,
		"powergenerated": 0,
		"cost": 0,
		"newbill": 0,
		"roi": 0,
		"breakeven": 0
	};
	
	if (category === "Residential"){
		data.cusType = "Residential";
		if ( billamount <= 1000 ) {
			data.slab = "Slab 1";
			data.slabrate = 5;
			data.totalunits = billamount/data.slabrate;
			data.units = data.totalunits;
			data.dailyunits = data.totalunits/30;
			data.savings = 0;
			data.maxplantcapacity = 0;
			// maxplantcapacity = ( totalunits - 200 ) / (30 * 4);
			data.plantarea = data.maxplantcapacity * 100;
		}
		else if( billamount > 1000 & billamount <= 1719 ) {
			data.slab = "Slab 2";
			data.slabrate = 7.2;
			data.units = (billamount- 1000)/data.slabrate;
			data.totalunits = 200 + data.units;
			data.dailyunits = data.totalunits/30;
			data.savings = data.units * (data.slabrate - data.solarrate) + 0;
			data.maxplantcapacity = ( data.totalunits - 200 ) / (30 * 4);
			data.plantarea = data.maxplantcapacity * 100;
			
		}
		else if( billamount > 1720 & billamount <= 2570 ) {
			data.slab = "Slab 3";
			data.slabrate = 8.5;
			data.units = (billamount- 1719)/data.slabrate;
			data.totalunits = 300 + data.units;
			data.dailyunits = data.totalunits/30;
			data.savings = data.units * (data.slabrate - data.solarrate) + 220;
			data.maxplantcapacity = ( data.totalunits - 200 ) / (30 * 4);
			data.plantarea = data.maxplantcapacity * 100;
			
		}
		else if ( billamount > 2570 & billamount <= 6170 ) {
			data.slab = "Slab 4";
			data.slabrate = 9.0;
			data.units = (billamount- 2570)/data.slabrate;
			data.totalunits = 400 + data.units;
			data.dailyunits = data.totalunits/30;
			data.savings = data.units * (data.slabrate - data.solarrate) + 570;
			data.maxplantcapacity = ( data.totalunits - 200 ) / (30 * 4);
			data.plantarea = data.maxplantcapacity * 100;
			
		}
		else if ( billamount > 6170) {
			data.slab = "Slab 5"
			data.slabrate = 9.5;
			data.units = (billamount- 6170)/data.slabrate;
			data.totalunits = 800 + data.units;
			data.dailyunits = data.totalunits/30;
			data.savings = data.units * (data.slabrate - data.solarrate) + 2170;
			data.maxplantcapacity = ( data.totalunits - 200 ) / (30 * 4);
			data.plantarea = data.maxplantcapacity * 100;
		}

		data.lifetimesavings = data.savings * 300;
		data.powergenerated = data.maxplantcapacity * 4 * 365 * 25/1000;
		data.newbill = billamount - data.savings;
		data.cost = data.maxplantcapacity * 0.6;
		data.roi = (((data.lifetimesavings/100000) - data.cost) / data.cost) * 100;
		data.breakeven = data.cost * 100000/ (data.savings * 12);
	}

	if (category === "Commercial"){
		data.cusType = "Commercial";

		data.slabrate = 8;

		data.units = (billamount)/data.slabrate;
		data.totalunits = data.units;
		data.dailyunits = data.totalunits/30;
		data.savings = data.units * (data.slabrate - data.solarrate);
		data.maxplantcapacity = ( data.totalunits) / (30 * 4);
		data.plantarea = data.maxplantcapacity * 100;

		data.lifetimesavings = data.savings * 300;
		data.powergenerated = data.maxplantcapacity * 4 * 365 * 25/1000;
		data.newbill = billamount - data.savings;
		data.cost = data.maxplantcapacity * 0.6;
		data.roi = (((data.lifetimesavings/100000) - data.cost) / data.cost) * 100;
		data.breakeven = data.cost * 100000/ (data.savings * 12);
	}

	if (category === "Industrial"){
		data.cusType = "Industrial";

		data.slabrate = 7;

		data.units = (billamount)/data.slabrate;
		data.totalunits = data.units;
		data.dailyunits = data.totalunits/30;
		data.savings = data.units * (data.slabrate - data.solarrate);
		data.maxplantcapacity = ( data.totalunits) / (30 * 4);
		data.plantarea = data.maxplantcapacity * 100;

		data.lifetimesavings = data.savings * 300;
		data.powergenerated = data.maxplantcapacity * 4 * 365 * 25/1000;
		data.newbill = billamount - data.savings;
		data.cost = data.maxplantcapacity * 0.6;
		data.roi = (((data.lifetimesavings/100000) - data.cost) / data.cost) * 100;
		data.breakeven = data.cost * 100000/ (data.savings * 12);
	}

	console.log("Customer of State: " + state);
	console.log("Customer Type: "+ data.cusType);
	console.log("Bill Amount Monthly: " + billamount);
	console.log(data.slab);
	console.log("Units in Slab : "+ data.units);
	console.log("Total Units : "+ data.totalunits);
	console.log("Max Plant Capacity :" + data.maxplantcapacity);
	console.log("Plant Area Sq.ft.:" + data.plantarea);
	console.log("Daily Units : "+ data.dailyunits);
	console.log("Savings : Rs. "+ data.savings);
	console.log("Life Time Savings : Rs. "+ data.lifetimesavings);

	return data;
}