<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title><?php echo $page_title; ?> | Ilios Power</title>
<meta name="description" content="<?php echo $page_meta; ?>">
<meta name="keywords" content="<?php echo $page_keywords; ?>">
<meta property="og:title" content="<?php echo $page_title; ?> | Ilios Power"/>
<meta property="og:description" content="<?php echo $page_meta; ?>">
<meta property="og:image" content="<?php echo $page_img; ?>"/>
<meta property="og:site_name" content="<?php echo $site_name; ?>"/>
<meta property="og:url" content="<?php echo $site_url; ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500|Raleway:300,400,600|Playfair+Display" rel="stylesheet">
<link rel="icon" type="image/png" href="/images/favicon.png" />
<link rel="stylesheet" href="css/bootstrap.css">
<link rel="stylesheet" href="css/main.css">
<script src="js/jquery.js"></script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-96991337-1', 'auto');
  ga('send', 'pageview');

</script>
</head>
<body>

<div class="logodiv"><a href="/"><img src="images/logo4.png" /></a></div>

<div id="callus">
<img src="images/phone.png" style="height:18px;" /> <span class="f500">Call us:</span> 040-3959 4545
</div>


<div class="container-fluild" id="outer">

<div class="menu">
<div class="menuitem"><a href="index.php">Home</a></div>
<div class="menuitem"><a href="residential.php">Residential</a></div>
<div class="menuitem"><a href="commercial.php">Commercial</a></div>
<div class="menuitem"><a href="industrial.php">Industrial</a></div>
<div class="menuitem"><a href="asset.php">Asset Management</a></div>
<div class="menuitem"><a href="about.php">About Us</a></div>
<div class="menuitem"><a href="#getstarted" style="font-weight:500; letter-spacing:0px;">Get a Free Quote</a></div>
</div>


<?php include($main_inc); ?>     
 
 
<div class="paditm" style="background:url(images/pw_maze_white.png); padding:100px 30px;" id="getstarted">
<div class="row">
<div class="col-xs-6 col-xs-offset-3 text-center">
<h2 class="h1">Switch to Solar with Ilios</h2>

<div class="form-group crisp" id="error_messages" style="display:none"></div>
<div class="form-group crisp alert alert-success" id="success_messages" style="display:none"></div>

<form class="form" id="contactform" name="contactform" method="post" action="email.php">
<div class="form-group">
<input type="text" class="form-control" name="fname" placeholder="Full Name" />
</div>
<div class="form-group">
<input type="text" class="form-control" name="email" placeholder="Email" />
</div>
<div class="form-group">
<input type="text" class="form-control" name="phone" placeholder="Phone Number" />
</div>
<div class="form-group">
<input type="submit" class="btn btn-primary" value="Get a Free Quote"/>
</div>

<div class="form-group" style="font-family:Arial, Helvetica, sans-serif;">
<img src="images/phone.png" style="height:20px;" /> <span class="f500">or call us:</span> 040-3959 4545
</div>

</form>

</div>
</div>
</div>


<div class="paditx whysolar">
<div class="row row-eq-height">

<div class="col-sm-3" style="background:#FF703B; margin-right:50px;">
<div class="whys">
<img src="images/whysolar.png" class="img-responsive" style="margin:0px auto;" />
</div>
</div>

<div class="col-sm-3 colblock">
<h3 class="h3b">Save Money</h3>
<img src="images/save.png" class="img-responsive bimage" />
Solar power reduces your monthly power bills from 25% to 75%! Also gain tax incentives.
</div>

<div class="col-sm-3 colblock">
<h3 class="h3b">Go Green</h3>
<img src="images/green.png" class="img-responsive bimage" />
Play your part in reducing pollution and promoting green environment
</div>


<div class="col-sm-3 colblock">
<h3 class="h3b">Reliable Energy</h3>
<img src="images/power.png" class="img-responsive bimage" />
Gain access to unlimited green and reliable source of energy with control on costs
</div>


</div>
</div>


      
</div>

<div class="text-center sfoot">
2017 &copy; Ilios Power, Hyderabad<a href="http://www.vivomedia.in" target="_blank"><img src="/images/vivomedia.png" height="20" style="margin-top:-5px;" /></a>
</div>


<script src="/js/bootstrap.min.js"></script>
<script src="/js/validate.js"></script>

<script>
$(document).ready(function(){
  $("a").on('click', function(event) {
    if (this.hash !== "") {
      event.preventDefault();
      var hash = this.hash;
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 800, function(){
        window.location.hash = hash;
      });
    }
  });
});
</script>

<script>
 $(document).ready(function() {
	 
	  	$("#contactform").validate({
			ignore: ".ignore",
			errorPlacement: function(error, element) {},
			rules:{
				fname: { required:true, minlength: 3, maxlength:100},
				phone: { required:true, number:true, minlength: 8, maxlength:12},
				email: { required:true, email:true},
		},
			messages:{},	
			submitHandler: function(form) {
          $.ajax({
            type: "POST",
            url: "/ajax/saveContact.php",
            data: $(form).serialize(),
						dataType: 'json',
            success: function(data) {
							if (data.status == '1') {
								$('#fname').val('');
								$('#email').val('');
								$('#phone').val('');
								
								$('#success_messages').show().html(data.message);
								$('#error_messages').hide().html('');
								$('#contactform').hide();
							} else {
								$('#error_messages').show().html(data.message);
							}
						}
          });
          return false;
      }	,	
		});
	});

 </script>

<div class="modal fade" id="solarcalc" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Calculator</h4>
      </div>
      <div class="modal-body">
<div class="row">
			<div class="col-md-10 col-md-offset-1">
				<div class="form-group" id="calcmain">
							<label for="inputSelectState" class="
							 control-label">Select State:</label>
							<div class="">
								<select name="SelectState" id="inputSelectState" class="form-control" required="required" value="Andhra Pradesh">
				                  <option value="Chandigarh">Chandigarh</option>
				                  <option value="Delhi">Delhi</option>
				                  <option value="Uttar Pradesh">Uttar Pradesh</option>
				                  <option value="Haryana">Haryana</option>
				                  <option value="Himachal Pradesh">Himachal Pradesh</option>
				                  <option value="Jammu and Kashmir">Jammu and Kashmir</option>
				                  <option value="Punjab">Punjab</option>
				                  <option value="Uttarakhand">Uttarakhand</option>
				                  <option value="Bihar">Bihar</option>
				                  <option value="Jharkhand">Jharkhand</option>
				                  <option value="West Bengal">West Bengal</option>
				                  <option value="Sikkim">Sikkim</option>
				                  <option value="Arunachal Pradesh">Arunachal Pradesh</option>
				                  <option value="Assam">Assam</option>
				                  <option value="Nagaland">Nagaland</option>
				                  <option value="Manipur">Manipur</option>
				                  <option value="Mizoram">Mizoram</option>
				                  <option value="Tripura">Tripura</option>
				                  <option value="Meghalaya">Meghalaya</option>
				                  <option value="Odisha">Odisha</option>
				                  <option value="Chhattisgarh">Chhattisgarh</option>
				                  <option value="Andhra Pradesh" selected="selected">Andhra Pradesh</option>
				                  <option value="Karnataka">Karnataka</option>
				                  <option value="Puducherry">Puducherry</option>
				                  <option value="Tamilnadu">Tamilnadu</option>
				                  <option value="Kerala">Kerala</option>
				                  <option value="Goa">Goa</option>
				                  <option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
				                  <option value="Daman and Diu">Daman and Diu</option>
				                  <option value="Maharashtra">Maharashtra</option>
				                  <option value="Madhya Pradesh">Madhya Pradesh</option>
				                  <option value="Gujarat">Gujarat</option>
				                  <option value="Rajasthan">Rajasthan</option>
				                  <option value="Lakshadeep">Lakshadeep</option>
				                  <option value="Andman and Nicobar Islands">Andman and Nicobar Islands</option>
				                  <option value="Telangana">Telangana</option>
				                  <option value="Puducherry">Puducherry</option>
								</select>
							</div>
							<br>
							<label for="inputCategory" class="
							 control-label">Category:</label>
							<div class="">
								<select name="Category" id="inputCategory" class="form-control" required="required">
									<option value="Residential">Residential</option>
									<option value="Commercial">Commercial</option>
									<option value="Industrial">Industrial</option>
								</select>
							</div>
							<br>
							<label for="inputBillAmount" class="
							 control-label">Bill Amount:</label>
							<div class="">
								<input type="number" name="billamount" id="inputBillamount" class="form-control" value="1500" min="{1000}" max="" step="100" required="required" title="">
							</div>
							<div>
								<br>
								<!-- <label for="inputPercentUse" class="control-label">Monthly Bill Reduction:</label>
								<div>
									<input id="inputPercentUse" data-slider-id='ex1Slider' type="text" data-slider-min="0" data-slider-max="100" data-slider-step="1" data-slider-value="50"/>
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
								</div> -->
								<button type="submit" class="btn btn-primary" onclick="calculate()">Calculate</button>
							</div>
						</div>
                        
                <div id="calcresults" style="display:none;">
				<div class="alert alert-warning" id="capacityAlert">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
					<strong>Solar Plant with capacity less than 1 kW is not viable</strong>
				</div>
				<div class="panel panel-default">
					<div class="panel-heading"><h3>Estimated System Requirements</h3></div>
					<div class="panel-body">
						<div class="row">
							<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
								<label for="plantcapacity" class="control-label"> Plant Capacity</label>
								<h5 id="plantcapacityval"></h5>
							</div>
							<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
								<label for="plantarea" class="control-label"> Plant Area</label>	
								<h5 id="plantareaval"></h5>
							</div>
						</div>
						<div class="row">
							<table class="table table-hover">
								<thead>
									<tr>
										<th></th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>Cost</td>
										<td><span id="cost"></span></td>
									</tr>
									<tr>
										<td>Monthly Bill with Solar</td>
										<td><span id="billreduction"></span></td>
									</tr>
									<tr>
										<td>Life Time Savings</td>
										<td><span id="totalsavings"></span></td>
									</tr>
									<tr>
										<td>RoI</td>
										<td><span id="roi"></span></td>
									</tr>
									<tr>
										<td>Power Generated</td>
										<td><span id="powergenerated"></span></td>
									</tr>
									<tr>
										<td>Breakeven</td>
										<td><span id="breakeven"></span></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				        <button type="submit" class="btn btn-primary" onclick="recalculate()">Re-Calculate</button>
				</div>
            </div>
            
			</div>
      </div>
    </div>
  </div>
</div>
    
    
<script type="text/javascript" src="/js/calc.js"></script>

<script type="text/javascript">
		function recalculate() {
			$('#calcmain').toggle();
			$('#calcresults').toggle();
        }

            function calculate() {
			$('#calcmain').toggle();
			$('#calcresults').toggle();
			var billamt = document.getElementById('inputBillamount').value;
			var cat = document.getElementById('inputCategory').value;
			var state = document.getElementById('inputSelectState').value;
			// var percentuse = document.getElementById('inputPercentUse').value;
			percentuse = 50;
			
			result = solarCalc(billamt, cat, state, percentuse);
			
			console.log(result);
			document.getElementById('plantcapacityval').innerHTML = result["maxplantcapacity"].toFixed(2) + " kW";
			document.getElementById('plantareaval').innerHTML = result["plantarea"].toFixed(2) + " Sq.Ft.";
			document.getElementById('cost').innerHTML = result.cost.toFixed(2) + " Lacs INR"
			document.getElementById('billreduction').innerHTML = result.newbill.toFixed(2) + " INR";
			document.getElementById('totalsavings').innerHTML = (result["lifetimesavings"]/100000).toFixed(2)+" Lacs INR";
			document.getElementById('roi').innerHTML =  result.roi.toFixed(2) + " %";
			document.getElementById('powergenerated').innerHTML = result.powergenerated.toFixed(2) + " kWh";
			document.getElementById('breakeven').innerHTML = result.breakeven.toFixed(2) + " years";

			if(result.maxplantcapacity < 1){
				$('#capacityAlert').show();
			}
			else{
				$('#capacityAlert').hide();
			}
		}

		$('#inputPercentUse').slider({
			formatter: function(value) {
				return 'Reduction : ' + value + "%";
			}
		});

		$(document).ready(function() {
		    var opt = $("#inputSelectState option").sort(function (a,b) { return a.value.toUpperCase().localeCompare(b.value.toUpperCase()) });
		    $("#inputSelectState").append(opt);
		    $("#inputSelectState").val("Andhra Pradesh");
		});
	</script>   
    
</body>
</html>
