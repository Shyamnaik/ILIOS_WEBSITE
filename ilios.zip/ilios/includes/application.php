<?php
$err_display = 1;
error_reporting($err_display);//ini_set("display_errors", '0');
ini_set('display_errors',$err_display);
date_default_timezone_set('Asia/Calcutta');

$site_url="http://www.iliospower.in";
$site_name="Ilios Power";
$site_domain="iliospower.in";

ini_set("session.cookie_domain", ".".$site_domain."");
session_name("".$site_domain."");
session_set_cookie_params(36000,"/",".".$site_domain."");
session_start();

//include('functions.php');
function cleanPhone($phone) {
	if ($phone) {
		$count = strlen($phone);
		$start = $count - 10;
		return substr($phone, $start, $count);
	}
}
function cleanup($array) {
	foreach($array as $key=>$value) {
      	if(is_array($value)) { 
	  		cleanup($value); 
	  	} else { 
	  		$array[$key] = mysql_real_escape_string($value); 
		}
    }
   return $array;
}


if (!empty($_POST)) { cleanup($_POST); }
if (!empty($_GET)) { cleanup($_GET); }


$db_host="localhost";
$db_name="ilios_ilios";
$username="ilios_iliosu";
$password="silBkQ87ZP?Q";
$conn=mysql_connect($db_host,$username,$password);
mysql_select_db($db_name) or die('NO:'.mysql_error());



if(empty($conn))
{
echo "NO DB";
header("location:".$site_url."/404.php");
}

?>