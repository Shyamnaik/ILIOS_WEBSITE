<?php
//include("includes/application.php");
$page_keywords="";

include('includes/Mobile_Detect.php');
$detect = new Mobile_Detect;
//1-Laptop, 2-Tab, 3-Mobile
$system=1;
if($detect->isTablet() ){
 $system=2; 
}
if( $detect->isMobile() && !$detect->isTablet() ){
	$system=3; 
}




$page_title='Residential Rooftops Solar Solutions in India';
$page_meta='We offer affordable and world-class solar solutions to power your home. Be it Independent Houses, Gated Communities or High Rise Buildings we make it easy right from installtion to maintenance. ';
$page_keywords='solar, solar rooftops, residential solar, highrise buildings, independent houses, gated communities';

$fbtitle=$page_title;
$fbimage='';
$fbdescription=$page_meta;

$mobile=0;
if($system==3)
{
	$mobile=1;
	$main_inc = "modules/residential.php"; 
	include("template-mobile.php");
}
else
{
	$main_inc = "modules/residential.php"; 
	include("template.php");
}
//mysql_close($conn);
?>