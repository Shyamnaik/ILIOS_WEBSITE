<?php
include('../includes/application.php');


function validateMobile($phone) {
	$return = false;
	if ($phone) {
		$phone = cleanPhone($phone);
		if (($phone > 0) ) {
			$return = $phone;
		}
	}	
	return $return;
}
function validateEmail($email) {
	$return = false;
	if ($email) {
		if (!filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
		  $return = true;
		}
	}
	return $return;
}



$return['status'] = 2;
if (!empty($_POST)) {	
	if (!trim($_POST['fname'])) {
		$is_error = true;
		$errors['fname'] = "Please enter name";
	}
	if (!trim($_POST['phone'])) {
		$is_error = true;
		$errors['phone'] = "Please enter phone";
	}
	
	if (!validateEmail($_POST['email'])) {
		$is_error = true;
		$errors['email'] = "Please enter valid email";
	}
	
	
	if ($is_error == false) {
		$name = addslashes($_POST['fname']);
		$email = $_POST['email'];
		$phone = $_POST['phone'];		
		
		$q="insert into contact(`name`,`email`,`phone`) values ('".$name."','".$email."','".$phone."')";
		mysql_query($q);
		$id=mysql_insert_id();
        
$tom      = 'naveenvunnam@gmail.com';
$subjectm = 'New Lead from Website';
$messagem = $name."\r\n".$email."\r\n".$phone."\r\n";
$headersm = 'From: hello@iliospower.in' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($tom, $subjectm, $messagem, $headersm);


		if ($id) {
			$return['status'] = 1;
			$return['message'] = "Thank you for contacting us. We will get in touch with you soon.";
		} else {
			$return['message'] = "Something went wrong.";
		}

		
		
	} else {
		$return['message'] = implode('<br />', $errors);
	}	
}

echo json_encode($return);	
mysql_close($conn);
?>