<?php
//include("includes/application.php");
$page_keywords="";

include('includes/Mobile_Detect.php');
$detect = new Mobile_Detect;
//1-Laptop, 2-Tab, 3-Mobile
$system=1;
if($detect->isTablet() ){
 $system=2; 
}
if( $detect->isMobile() && !$detect->isTablet() ){
	$system=3; 
}


$page_title='';
$page_meta='';

$fbtitle=$page_title;
$fbimage='';
$fbdescription=$page_meta;

if($system==3)
{
	$main_inc = "modules/index.php"; 
	include("template.php");
}
else
{
	$main_inc = "modules/index.php"; 
	include("template.php");
}
//mysql_close($conn);
?>