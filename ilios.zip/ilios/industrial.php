<?php
//include("includes/application.php");
$page_keywords="";

include('includes/Mobile_Detect.php');
$detect = new Mobile_Detect;
//1-Laptop, 2-Tab, 3-Mobile
$system=1;
if($detect->isTablet() ){
 $system=2; 
}
if( $detect->isMobile() && !$detect->isTablet() ){
	$system=3; 
}


$page_title='Industrial Solar Solutions in India';
$page_meta='Switch to Solar. Ilios Power has the experience and expertise to help your industries switch to solar power. Great for Textile industry, food processing, metals, cement industry and more';
$page_keywords='solar solutions for industries, solar india, industrial solar, industrial solar plant, hyderabad, telangana, india, factories';


$fbtitle=$page_title;
$fbimage='';
$fbdescription=$page_meta;

$mobile=0;
if($system==3)
{
	$mobile=1;
	$main_inc = "modules/industrial.php"; 
	include("template-mobile.php");
}
else
{
	$main_inc = "modules/industrial.php"; 
	include("template.php");
}
//mysql_close($conn);
?>