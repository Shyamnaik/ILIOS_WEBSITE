
<?php
//include("includes/application.php");
$page_keywords="";

include('includes/Mobile_Detect.php');
$detect = new Mobile_Detect;
//1-Laptop, 2-Tab, 3-Mobile
$system=1;
if($detect->isTablet() ){
 $system=2; 
}
if( $detect->isMobile() && !$detect->isTablet() ){
	$system=3; 
}


$page_title='Solar Solutions for Businesses and Commercial Setups in India';
$page_meta='Switch to Solar. Ilios Power has the experience and expertise to help your business switch to solar power. Great for Hospitals, Educational Institutions, Hotels, Restaurants, Shopping Malls, Offices ';
$page_keywords='solar solutions for buildings, commercial solar, commercial solar plant, hyderabad, telangana, india, offices, hospitals, malls, commercial';


$fbtitle=$page_title;
$fbimage='';
$fbdescription=$page_meta;

$mobile=0;
if($system==3)
{
	$mobile=1;
	$main_inc = "modules/commercial.php"; 
	include("template-mobile.php");
}
else
{
	$main_inc = "modules/commercial.php"; 
	include("template.php");
}
//mysql_close($conn);
?>