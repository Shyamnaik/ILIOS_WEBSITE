<?php
//include("includes/application.php");
$page_keywords="";

include('includes/Mobile_Detect.php');
$detect = new Mobile_Detect;
//1-Laptop, 2-Tab, 3-Mobile
$system=1;
if($detect->isTablet() ){
 $system=2; 
}
if( $detect->isMobile() && !$detect->isTablet() ){
	$system=3; 
}


$page_title='Solar Power Plant Operations and Maintenance';
$page_meta='Ilios Power meticulous Operations and Maintenance strives for 100% plant uptime and maximum power generation.';
$page_keywords='solar, solar power, solar plant maintenance company, solar operations';


$fbtitle=$page_title;
$fbimage='';
$fbdescription=$page_meta;

$mobile=0;
if($system==3)
{
	$mobile=1;
	$main_inc = "modules/asset.php"; 
	include("template-mobile.php");
}
else
{
	$main_inc = "modules/asset.php"; 
	include("template.php");
}
//mysql_close($conn);
?>