<?php
//include("includes/application.php");
$page_keywords="";

include('includes/Mobile_Detect.php');
$detect = new Mobile_Detect;
//1-Laptop, 2-Tab, 3-Mobile
$system=1;
if($detect->isTablet() ){
 $system=2; 
}
if( $detect->isMobile() && !$detect->isTablet() ){
	$system=3; 
}


$page_title='Leading Solar Power Solutions Company';
$page_meta='Ilios Power is one of Indias fastest growing Solar Energy Companies in India founded by IIT alumni. Our friendly team will make sure you get the best experience from initial consultation to installation to maintenance.';
$page_keywords='solar, solar power, solar plant, setup solar power plant in telangana, ilios power, best solar company, solar power plant, about ilios power, hyderabad, telangana, andhra pradesh, india, solar';

$fbtitle=$page_title;
$fbimage='';
$fbdescription=$page_meta;

if($system==3)
{
	$main_inc = "modules/index.php"; 
	include("template-mobile.php");
}
else
{
	$main_inc = "modules/index.php"; 
	include("template.php");
}
//mysql_close($conn);
?>