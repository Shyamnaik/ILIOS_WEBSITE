<?php
//include("includes/application.php");
$page_keywords="";

include('includes/Mobile_Detect.php');
$detect = new Mobile_Detect;
//1-Laptop, 2-Tab, 3-Mobile
$system=1;
if($detect->isTablet() ){
 $system=2; 
}
if( $detect->isMobile() && !$detect->isTablet() ){
	$system=3; 
}


$page_title='About Us';
$page_meta='Built by engineers, Ilios Power is a company with a strong focus on quality and efficiency. Our highly qualified engineers have been at the forefront of the solar industry in India since its dawn.';
$page_keywords='ilios power, best solar company, solar power plant, about ilios power, hyderabad, telangana, andhra pradesh';

$fbtitle=$page_title;
$fbimage='';
$fbdescription=$page_meta;

$mobile=0;
if($system==3)
{
	$mobile=1;
	$main_inc = "modules/about.php"; 
	include("template-mobile.php");
}
else
{
	$main_inc = "modules/about.php"; 
	include("template.php");
}
//mysql_close($conn);
?>